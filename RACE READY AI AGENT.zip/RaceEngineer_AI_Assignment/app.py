import io
import math
from pathlib import Path

import matplotlib.pyplot as plt
import pandas as pd
import streamlit as st

APP_TITLE = "RaceEngineer AI"
DATA_PATH = Path(__file__).parent / "sample_telemetry.csv"

st.set_page_config(page_title=APP_TITLE, page_icon="🏁", layout="wide")

# ---------- Engineering tools used by the agent ----------
def telemetry_tool(df: pd.DataFrame) -> dict:
    """Calculate descriptive telemetry metrics from available numeric channels."""
    result = {"rows": len(df), "columns": list(df.columns), "metrics": {}}
    for col in ["speed_kmh", "throttle_pct", "brake_pct", "lat_g", "long_g", "lap_time_s"]:
        if col in df.columns and pd.api.types.is_numeric_dtype(df[col]):
            series = df[col].dropna()
            if not series.empty:
                result["metrics"][col] = {
                    "mean": float(series.mean()),
                    "min": float(series.min()),
                    "max": float(series.max()),
                }
    if "speed_kmh" in df.columns:
        result["metrics"]["speed_kmh"]["std"] = float(df["speed_kmh"].std()) if len(df) > 1 else 0.0
    if "brake_pct" in df.columns and "speed_kmh" in df.columns:
        braking = df[df["brake_pct"] > 10]
        result["braking_samples"] = int(len(braking))
        result["mean_speed_under_braking_kmh"] = float(braking["speed_kmh"].mean()) if not braking.empty else None
    if "lat_g" in df.columns:
        result["peak_abs_lateral_g"] = float(df["lat_g"].abs().max())
    return result


def dynamics_tool(question: str, df: pd.DataFrame | None = None) -> list[str]:
    """A transparent rules-based engineering reasoning tool; not a substitute for validation."""
    q = question.lower()
    findings = []
    if any(word in q for word in ["understeer", "push", "front wash"]):
        findings += [
            "Possible mechanism: the front tyres may be reaching their available lateral-force limit before the rear tyres.",
            "Check front/rear tyre temperatures and pressures, steering angle versus lateral acceleration, front suspension geometry, and aero balance.",
            "Do not change setup from this symptom alone; confirm whether it occurs on entry, mid-corner, or exit."
        ]
    elif any(word in q for word in ["oversteer", "loose", "rear step", "snap"]):
        findings += [
            "Possible mechanism: rear lateral-force demand may be exceeding rear tyre capacity, or rear load may be changing rapidly.",
            "Check throttle application, rear tyre temperatures/pressures, differential behaviour, rear toe, and transient damper response.",
            "Separate entry, mid-corner, and exit oversteer before recommending a setup change."
        ]
    elif any(word in q for word in ["brak", "lock", "stopping"]):
        findings += [
            "Inspect brake-pressure traces, wheel-speed data, longitudinal acceleration, and front/rear brake balance.",
            "A lock-up hypothesis needs individual wheel speeds or video; vehicle speed and brake percentage alone cannot prove a lock-up.",
            "Compare braking onset, peak deceleration, and release phase at the same corner and similar entry speed."
        ]
    elif any(word in q for word in ["traction", "wheelspin", "exit"]):
        findings += [
            "Possible causes include excess drive torque for available grip, rear load sensitivity, differential setup, or abrupt throttle application.",
            "Compare throttle, wheel speeds, longitudinal acceleration, and yaw rate through corner exit.",
            "If wheel-speed channels are unavailable, treat wheelspin as a hypothesis rather than a measured fact."
        ]
    else:
        findings += [
            "First identify the phase of the corner: braking/entry, mid-corner, or throttle/exit.",
            "Compare speed, throttle, brake, lateral acceleration, and longitudinal acceleration against a reference lap.",
            "A reliable diagnosis needs repeatable laps, consistent conditions, and appropriate sensor channels."
        ]
    if df is not None and "lat_g" in df.columns:
        peak = float(df["lat_g"].abs().max())
        findings.append(f"Dataset context: peak absolute lateral acceleration is {peak:.2f} g in the currently loaded data.")
    return findings


def strategy_tool(lap_time_s: float, pit_loss_s: float, laps: int, fuel_per_lap_kg: float) -> dict:
    return {
        "race_distance_laps": int(laps),
        "estimated_green_flag_time_s": float(lap_time_s * laps),
        "estimated_pit_loss_s": float(pit_loss_s),
        "estimated_total_with_one_stop_s": float(lap_time_s * laps + pit_loss_s),
        "estimated_fuel_kg": float(fuel_per_lap_kg * laps),
        "assumption": "Constant lap time, one pit stop, and constant fuel use per lap; excludes traffic, degradation, safety cars, and refuelling rules."
    }


def agent_router(task: str, question: str, df: pd.DataFrame, strategy_inputs: dict | None = None) -> dict:
    """Simple tool-using agent: selects a tool based on user intent and returns traceable output."""
    task = task.lower()
    if task == "telemetry analysis":
        return {"tool_selected": "telemetry_tool", "reason": "The request asks for numerical analysis of telemetry channels.", "output": telemetry_tool(df)}
    if task == "vehicle dynamics diagnosis":
        return {"tool_selected": "dynamics_tool", "reason": "The request asks for an engineering interpretation of a handling symptom.", "output": dynamics_tool(question, df)}
    if task == "race strategy calculator":
        values = strategy_inputs or {}
        return {"tool_selected": "strategy_tool", "reason": "The request contains race-distance and pit-strategy assumptions.", "output": strategy_tool(**values)}
    return {
        "tool_selected": "engineering_knowledge_tool",
        "reason": "The request is a general motorsport engineering question; provide a cautious workflow.",
        "output": dynamics_tool(question, df)
    }


# ---------- UI ----------
st.markdown("""
<style>
.block-container {padding-top: 1.5rem; padding-bottom: 2rem;}
.hero {padding: 1.25rem 1.4rem; border: 1px solid #343944; border-radius: 16px;
       background: linear-gradient(115deg, #171b25 0%, #222a38 100%); margin-bottom: 1rem;}
.hero h1 {margin: 0; color: #f3f5f8; font-size: 2.15rem;}
.hero p {color: #b8c1d1; margin: .35rem 0 0 0;}
.small-note {color: #9ca7b8; font-size: .88rem;}
</style>
<div class="hero">
  <h1>🏁 RaceEngineer AI</h1>
  <p>A tool-using motorsport engineering assistant for telemetry, vehicle dynamics, and race-strategy calculations.</p>
</div>
""", unsafe_allow_html=True)

with st.sidebar:
    st.header("Control Room")
    st.caption("Assignment: AI Agent Development")
    st.markdown("**Agent tools**")
    st.write("1. Telemetry analysis")
    st.write("2. Vehicle dynamics advisor")
    st.write("3. Race strategy calculator")
    st.write("4. Engineering workflow advisor")
    st.divider()
    st.caption("Demo dataset is synthetic and intended for education.")

uploaded = st.file_uploader("Upload telemetry CSV (optional)", type=["csv"])
if uploaded is not None:
    try:
        df = pd.read_csv(uploaded)
        data_source = "Uploaded CSV"
    except Exception as exc:
        st.error(f"Could not read the CSV: {exc}")
        st.stop()
else:
    df = pd.read_csv(DATA_PATH)
    data_source = "Built-in sample_telemetry.csv"

st.caption(f"Data source: {data_source} · {len(df)} rows")
st.markdown("### Choose an agent task")
task = st.selectbox(
    "Task",
    ["Telemetry analysis", "Vehicle dynamics diagnosis", "Race strategy calculator", "General engineering question"]
)

question = st.text_area(
    "Describe the question or symptom",
    value="The car seems to understeer in medium-speed corners. What should I investigate?",
    height=90
)

strategy_inputs = None
if task == "Race strategy calculator":
    c1, c2, c3, c4 = st.columns(4)
    with c1:
        lap_time = st.number_input("Average lap time (s)", min_value=30.0, max_value=300.0, value=92.5, step=0.5)
    with c2:
        pit_loss = st.number_input("Pit-lane time loss (s)", min_value=0.0, max_value=180.0, value=22.0, step=1.0)
    with c3:
        laps = st.number_input("Race distance (laps)", min_value=1, max_value=500, value=30, step=1)
    with c4:
        fuel = st.number_input("Fuel use (kg/lap)", min_value=0.0, max_value=20.0, value=2.4, step=0.1)
    strategy_inputs = {
        "lap_time_s": float(lap_time),
        "pit_loss_s": float(pit_loss),
        "laps": int(laps),
        "fuel_per_lap_kg": float(fuel),
    }

if st.button("Run engineering agent", type="primary", use_container_width=True):
    result = agent_router(task, question, df, strategy_inputs)
    st.success(f"Agent selected: `{result['tool_selected']}`")
    st.caption(result["reason"])
    output = result["output"]

    if task == "Telemetry analysis":
        metrics = output.get("metrics", {})
        cols = st.columns(4)
        cards = [
            ("Samples", f"{output['rows']:,}"),
            ("Peak |lateral G|", f"{output.get('peak_abs_lateral_g', float('nan')):.2f} g"),
            ("Mean speed", f"{metrics.get('speed_kmh', {}).get('mean', float('nan')):.1f} km/h"),
            ("Braking samples", str(output.get("braking_samples", "N/A"))),
        ]
        for col, (label, value) in zip(cols, cards):
            col.metric(label, value)
        st.markdown("#### Channel summary")
        summary_rows = []
        for name, values in metrics.items():
            summary_rows.append({"Channel": name, **{k: round(v, 3) for k, v in values.items()}})
        st.dataframe(pd.DataFrame(summary_rows), use_container_width=True, hide_index=True)
        if "time_s" in df.columns:
            chart_channels = [c for c in ["speed_kmh", "throttle_pct", "brake_pct", "lat_g", "long_g"] if c in df.columns]
            if chart_channels:
                st.markdown("#### Telemetry traces")
                st.line_chart(df.set_index("time_s")[chart_channels], height=300)
        if "speed_kmh" in df.columns and "lat_g" in df.columns:
            st.markdown("#### Speed vs lateral acceleration")
            st.scatter_chart(df, x="speed_kmh", y="lat_g")
        st.info("Interpretation note: summary statistics do not independently identify the cause of a vehicle-dynamics issue.")
    elif task == "Race strategy calculator":
        st.markdown("#### Strategy estimate")
        for key, value in output.items():
            if key == "assumption":
                st.caption(value)
            else:
                st.write(f"**{key.replace('_', ' ').title()}:** {value:,.2f}" if isinstance(value, float) else f"**{key.replace('_', ' ').title()}:** {value}")
    else:
        st.markdown("#### Agent findings")
        for i, item in enumerate(output, 1):
            st.write(f"{i}. {item}")
        st.warning("These are investigation prompts, not a validated diagnosis or an automatic setup recommendation.")

with st.expander("Preview loaded data"):
    st.dataframe(df.head(20), use_container_width=True, hide_index=True)

with st.expander("Agent architecture / schema"):
    st.code("""
User request
    |
    v
Agent Router (intent selection)
    |-------------------|--------------------|-------------------|
    v                   v                    v
Telemetry Tool     Dynamics Tool       Strategy Tool
    |                   |                    |
    v                   v                    v
Statistics/plots    Investigation      Time/fuel estimates
    |___________________|____________________|
                        |
                        v
              Results + assumptions + caveats
""", language="text")

st.markdown("---")
st.markdown('<p class="small-note">Educational prototype. The bundled telemetry is synthetic, not real vehicle data. Validate all engineering decisions with real measurements and qualified review.</p>', unsafe_allow_html=True)
