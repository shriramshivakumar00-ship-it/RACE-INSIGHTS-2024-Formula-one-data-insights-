# RaceEngineer AI — Architecture / Schema

```mermaid
flowchart TD
    A[User input / telemetry CSV] --> B[Agent Router]
    B -->|Telemetry request| C[Telemetry Tool]
    B -->|Handling symptom| D[Vehicle Dynamics Tool]
    B -->|Race assumptions| E[Race Strategy Tool]
    B -->|General question| F[Engineering Workflow Tool]
    C --> G[Metrics and plots]
    D --> H[Investigation checklist]
    E --> I[Time and fuel estimates]
    F --> H
    G --> J[Streamlit results UI]
    H --> J
    I --> J
    J --> K[Assumptions and limitations]
```

## Input
- User-selected task
- Natural-language symptom or question
- Optional CSV telemetry data
- For strategy: average lap time, pit loss, number of laps, fuel per lap

## Processing
1. The router reads the selected task.
2. It selects the corresponding Python tool.
3. The tool calculates statistics or generates engineering investigation prompts.
4. The UI displays the tool selected, output, and caveats.

## Output
- Numeric telemetry summaries and charts
- Handling-diagnosis investigation checklist
- Estimated race time, pit-loss and fuel use
- Explanation of selected tool

## Why this is an agent prototype
The application has a routing layer and multiple callable tools. It chooses a tool according to the requested task and passes relevant data into that tool. The current version uses deterministic task selection rather than an LLM planner, so it is reproducible and requires no API key.

## Safety / validity
The telemetry data is synthetic. The outputs are for learning and are not validated setup recommendations. No automatic setup change should be made from this application alone.
